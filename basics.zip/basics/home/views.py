from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import Department,Docters
from . form import BookingForm

# Create your views here.
def index(request):
    person={
        'name':'ashiq',
        'place':'calicut',
        'age':19,
    }
    # numbers={
    #     'num1':[1,2,3,4,5,6,7,8,9,10]
    # },
    
    return render(request,'index.html',person)

def about(request):
    return render (request,'about.html')

def booking(request):
 if request.method == "POST":
     form=BookingForm(request.POST)
     if form.is_valid():
         form.save()
         return render(request,'confirmation.html')
 else: 
    form = BookingForm()
    dict_form={
        'form':form
    }
    return render(request,'booking.html',dict_form)

def docters(request):
    dict_doct = {
        'docters':Docters.objects.all()
    }
    return render(request,'docters.html',dict_doct)

def contacts(request): 
    return render(request,'contacts.html')

def departmenty(request):
     
      dict_dipa={
          'dep':Department.objects.all()
        
      }
      return render(request,'department.html',dict_dipa)
