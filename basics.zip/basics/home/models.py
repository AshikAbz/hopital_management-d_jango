from django.db import models

# Create your models here.
class Department(models.Model):
    dep_name=models.CharField(max_length=100)
    dep_description=models.TextField()

    def  __str__(self) -> str:
     return self.dep_name       #This function used to show return dep_name in admin section

class Docters(models.Model):
    doct_name=models.CharField(max_length=225)
    doct_spec=models.CharField(max_length=225)  
    dept_name=models.ForeignKey(Department, on_delete=models.CASCADE)
    doct_image=models.ImageField(upload_to='docters')
    def  __str__(self) -> str:
     return self.doct_name  

class Booking(models.Model):
    p_name=models.CharField(max_length=250)
    p_phone=models.CharField(max_length=10)
    p_email=models.EmailField()
    doct_name=models.ForeignKey(Docters,on_delete=models.CASCADE)
    booking_date=models.DateField()
    booked_on=models.DateField(auto_now=True) #to get which time they booking the date will be get as a date stamp

    def  __str__(self) -> str:
     return self.p_name