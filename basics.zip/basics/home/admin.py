from django.contrib import admin
from.models import Department
from.models import Docters,Booking
# Register your models here.
admin.site.register(Department)
admin.site.register(Docters)
class BookingAdmin(admin.ModelAdmin):
     list_display = ('id','p_name','p_phone','p_email','doct_name','booking_date')
admin.site.register(Booking,BookingAdmin)