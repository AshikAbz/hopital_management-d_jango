from django import forms
from .models import Booking

class DateInput(forms.DateInput):
    input_type= 'date'

class BookingForm(forms.ModelForm): #this calass use to take form's fields from Booking database table in html
    class Meta:
        model = Booking
        fields = '__all__'

        widgets={
            'booking_date':DateInput(),
        }
        lebels={
            'p_name':"Patient Name",
            'p_Phone':"Patient Number",
            'p_email':"Patient email",
            'Doct_name':"Docter Name",
        }